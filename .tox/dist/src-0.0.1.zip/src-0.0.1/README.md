'''Created an environemnt


conda create -n wineq python=3.7 -y 
'''Activated the enviroument
conda activate wineq

''' created requirements.txt file
'''install packages on the environment
pip install -r requirements.txt

