from setuptools import setup, find_packages

setup(
    name="src",
    version="0.0.1",
    description = "This is mlops imelementation for wineq model",
    author = "DineshKaarthik",
    packages = find_packages(),
    license = "MIT"




)